package com.example.ubiekg

import android.bluetooth.BluetoothSocket
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.util.Log

class GraphActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Retrieve the BluetoothSocket from the manager
        val bluetoothSocket = BluetoothSocketManager.bluetoothSocket
        if (bluetoothSocket != null) {
            Log.d("GraphActivity", "Sending SEND_FILE command immediately on start.")
            bluetoothSocket.outputStream.write("SEND_FILE\n".toByteArray())
        } else {
            Log.e("GraphActivity", "BluetoothSocket is null!")
        }

        setContent {
            GraphScreen(bluetoothSocket)
        }
    }
}

object BluetoothSocketManager {
    var bluetoothSocket: BluetoothSocket? = null
}

@Composable
fun GraphScreen(bluetoothSocket: BluetoothSocket?) {
    val graphData = remember { mutableStateOf<List<Pair<String, Float>>>(emptyList()) }
    val coroutineScope = rememberCoroutineScope()

    // Download data when the screen is displayed
    LaunchedEffect(Unit) {
        coroutineScope.launch {
            withContext(Dispatchers.IO) {
                downloadAndParseData(bluetoothSocket, graphData)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Text("Stress Data", style = MaterialTheme.typography.headlineMedium)

        Spacer(modifier = Modifier.height(16.dp))

        if (graphData.value.isNotEmpty()) {
            LineChart(data = graphData.value) // Pass graphData to LineChart
        } else {
            CircularProgressIndicator()
        }
    }
}

fun downloadAndParseData(
    bluetoothSocket: BluetoothSocket?,
    graphData: MutableState<List<Pair<String, Float>>>
) {
    val command = "SEND_FILE\n"
    try {
        if (bluetoothSocket == null) {
            Log.e("Bluetooth", "BluetoothSocket is null. Cannot send command.")
            return
        }

        Log.d("Bluetooth", "Sending command: $command")
        bluetoothSocket.outputStream.write(command.toByteArray())

        val inputStream = bluetoothSocket.inputStream ?: return
        val buffer = ByteArray(1024)
        val fileContent = StringBuilder()

        while (true) {
            val bytes = inputStream.read(buffer)
            val data = String(buffer, 0, bytes)
            Log.d("Bluetooth", "Received: $data")

            if (data.contains("START_FILE_TRANSFER")) {
                fileContent.clear()
            } else if (data.contains("END_FILE_TRANSFER")) {
                val parsedData = parseCsvData(fileContent.toString())
                graphData.value = parsedData
                break
            } else {
                fileContent.append(data)
            }
        }
    } catch (e: Exception) {
        Log.e("Bluetooth", "Error in communication: ${e.message}")
        e.printStackTrace()
    }
}





fun parseCsvData(content: String): List<Pair<String, Float>> {
    val lines = content.lines()
    return lines.mapNotNull { line ->
        val parts = line.split(",")
        if (parts.size == 2) {
            val timestamp = parts[0].trim()
            val value = parts[1].toFloatOrNull()
            if (value != null) timestamp to value else null
        } else null
    }
}


@Composable
fun LineChart(data: List<Pair<String, Float>>) {
    val chartData = data.mapIndexed { index, pair -> index to pair.second }
    val maxValue = chartData.maxOfOrNull { it.second } ?: 0f
    val minValue = chartData.minOfOrNull { it.second } ?: 0f

    Canvas(modifier = Modifier
        .fillMaxWidth()
        .height(300.dp)) {
        val width = size.width
        val height = size.height
        val spacing = width / chartData.size

        chartData.forEachIndexed { index, point ->
            if (index > 0) {
                val prevPoint = chartData[index - 1]
                drawLine(
                    color = Color.Blue,
                    start = Offset(
                        x = (index - 1) * spacing,
                        y = height - (prevPoint.second - minValue) / (maxValue - minValue) * height
                    ),
                    end = Offset(
                        x = index * spacing,
                        y = height - (point.second - minValue) / (maxValue - minValue) * height
                    ),
                    strokeWidth = 2f
                )
            }
        }
    }
}

fun filterDataByDate(data: List<Pair<String, Float>>, selectedDate: String): List<Pair<String, Float>> {
    return data.filter { it.first.startsWith(selectedDate) }
}
