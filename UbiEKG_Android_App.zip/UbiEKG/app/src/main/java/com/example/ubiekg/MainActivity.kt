package com.example.ubiekg

import android.Manifest
import android.bluetooth.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import java.util.Date
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.ubiekg.ui.theme.UbiEKGTheme
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.InputStream
import android.content.pm.ActivityInfo
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import java.util.Calendar
import android.app.DatePickerDialog
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.listener.OnChartValueSelectedListener
import com.github.mikephil.charting.highlight.Highlight
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import java.text.SimpleDateFormat
import java.util.Locale
import androidx.compose.ui.viewinterop.AndroidView
import android.util.Log

class MainActivity : ComponentActivity() {

    private var selectedDevice: BluetoothDevice? = null
    private var bluetoothSocket: BluetoothSocket? = null
    private val foundDevices = mutableStateListOf<BluetoothDevice>()

    // Screen management state
    private var currentScreen by mutableStateOf("LiveData") // Tracks which screen to show
    private var fileData by mutableStateOf("") // Holds the received file data
    val data = "timestamp,stressLevel,otherValues"
    val parts = data.split(",")

    val timestamp = try {
        SimpleDateFormat("HH:mm:ss", Locale.getDefault()).parse(parts[0])?.time?.toFloat() ?: 0f
    } catch (e: Exception) {
        0f // Fallback timestamp value
    }

    private val requestPermissionsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
            val allGranted = permissions.values.all { it }
            if (allGranted) {
                startBluetoothScan()
            } else {
                permissionDenied = true
            }
        }

    private var permissionDenied by mutableStateOf(false)
    private var showProgressIndicator by mutableStateOf(true)
    private var liveData by mutableStateOf("No Data Yet")
    private var rrInterval by mutableStateOf("")
    private var bpm by mutableStateOf("")
    private var rmssd by mutableStateOf("")
    private var Stress by mutableStateOf("")
    private var StressProgress by mutableStateOf("")
    private var RMSSDProgress by mutableStateOf("")
    private var heartRateStatus by mutableStateOf("")
    private var isConnected by mutableStateOf(false)
    private var areLeadsDisconnected by mutableStateOf(false)
    private var batteryPercentage by mutableStateOf("0%")

    private val bluetoothAdapter by lazy {
        (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val action: String = intent?.action ?: return
            if (BluetoothDevice.ACTION_FOUND == action) {
                val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                }

                device?.let {
                    val deviceName = if (ContextCompat.checkSelfPermission(
                            this@MainActivity,
                            Manifest.permission.BLUETOOTH_CONNECT
                        ) != PackageManager.PERMISSION_GRANTED
                    ) {
                        return
                    } else {
                        it.name ?: "Unnamed Device"
                    }

                    if (!foundDevices.contains(it) && deviceName == "UbiEKG") {
                        //if (!foundDevices.contains(it)) {
                        foundDevices.add(it)
                    }
                }
            }
        }
    }

    private val connectionStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val action: String = intent?.action ?: return
            when (action) {
                BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                    // Device-specific disconnection detected
                    isConnected = false
                    liveData = "Disconnected"
                    bluetoothSocket?.close() // Ensure the socket is closed
                    bluetoothSocket = null
                    Toast.makeText(this@MainActivity, "Device disconnected", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        super.onCreate(savedInstanceState)
        setContent {
            UbiEKGTheme {
                MainScreen()
            }
        }

        // Register connection state receiver
        val filter = IntentFilter()
        filter.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        registerReceiver(connectionStateReceiver, filter)

        startBluetoothScan() // Start scanning automatically on app launch
    }



    @Composable
    fun MainScreen() {
        when {
            currentScreen == "DataDisplay" -> DataDisplayScreen(fileData) // Show Data Display view
            areLeadsDisconnected -> DisconnectedScreen() // Show Leads Disconnected view
            isConnected -> LiveDataScreen() // Show Live Data view
            else -> DeviceSelectionScreen() // Show Device Selection view
        }
    }



    // Add this navigation function in MainActivity
    fun navigateToGraphScreen() {
        val intent = Intent(this, GraphActivity::class.java)
        startActivity(intent)
    }


    fun prepareChartLabels(rawData: String): List<String> {
        val lines = rawData.lines()
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

        return lines.map { line ->
            val parts = line.split(",")
            if (parts.isNotEmpty()) {
                try {
                    val timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                        .parse(parts[0]) // Parse timestamp
                    timeFormat.format(timestamp ?: Date()) // Format timestamp
                } catch (e: Exception) {
                    "" // Fallback if parsing fails
                }
            } else {
                ""
            }
        }
    }


    @Composable
    fun DataDisplayScreen(rawData: String) {
        val context = LocalContext.current
        val calendar = remember { Calendar.getInstance() }
        val selectedDate = remember { mutableStateOf(calendar.time) } // Default to current date

        // Filter and prepare the data for the chart
        val filteredData = remember(selectedDate.value) {
            filterDataByDate(rawData, selectedDate.value)
        }
        val chartData = remember(filteredData) { prepareChartData(filteredData) }
        val chartLabels = remember(filteredData) { prepareChartLabels(filteredData) }

        Column(modifier = Modifier.fillMaxSize()) {
            // Display chosen date
            Text(
                text = "${SimpleDateFormat("d/M/yyyy", Locale.getDefault()).format(selectedDate.value)}",
                style = MaterialTheme.typography.headlineLarge, // Larger text for the title
                modifier = Modifier
                    .padding(16.dp)
                    .align(Alignment.CenterHorizontally),
                textAlign = TextAlign.Center
            )

            // Buttons for date selection and returning to LiveData
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Button(
                    onClick = {
                        DatePickerDialog(
                            context,
                            { _, year, month, dayOfMonth ->
                                calendar.set(year, month, dayOfMonth)
                                selectedDate.value = calendar.time // Update selected date
                            },
                            calendar.get(Calendar.YEAR),
                            calendar.get(Calendar.MONTH),
                            calendar.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Select Date")
                }

                Spacer(modifier = Modifier.width(16.dp))

                Button(
                    onClick = { currentScreen = "LiveData" }, // Navigate back to LiveData
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Live Data")
                }
            }

            // Display the chart
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    LineChart(ctx).apply {
                        description.text = "Stress Over Time"
                        isDragEnabled = true
                        setScaleEnabled(true)
                        setPinchZoom(true)
                        xAxis.apply {
                            granularity = 1f
                            valueFormatter = IndexAxisValueFormatter(chartLabels)
                            setDrawLabels(true)
                        }
                    }
                },
                update = { chart ->
                    chart.data = chartData
                    chart.invalidate() // Refresh the chart

                    chart.setOnChartValueSelectedListener(object : OnChartValueSelectedListener {
                        override fun onValueSelected(e: Entry?, h: Highlight?) {
                            e?.let { entry ->
                                val index = entry.x.toInt()
                                if (index in chartLabels.indices) {
                                    val parts = filteredData.lines()[index].split(",")
                                    val bpm = parts[1]
                                    val rmssd = parts[2]
                                    val stress = entry.y // Use stress directly from entry.y

                                    // Use context passed to AndroidView
                                    val toastMessage = """
                            Time: ${chartLabels[index]}, Stress: $stress
                            BPM: $bpm, RMSSD: $rmssd
                        """.trimIndent()
                                    Toast.makeText(chart.context, toastMessage, Toast.LENGTH_LONG).show()
                                }
                            }
                        }

                        override fun onNothingSelected() {
                            // Optional: Handle no point selected
                        }
                    })
                }
            )


        }
    }

    // Helper Function to Filter Data by Date
    fun filterDataByDate(rawData: String, date: Date): String {
        val inputDateFormat = SimpleDateFormat("H:m:s d/M/yyyy", Locale.getDefault()) // Adjust to match your data format
        val dateOnlyFormat = SimpleDateFormat("d/M/yyyy", Locale.getDefault())       // For filtering by date

        val selectedDateString = dateOnlyFormat.format(date) // Format the selected date for comparison

        return rawData.lines().filter { line ->
            val parts = line.split(",")
            if (parts.size >= 4) { // Ensure the line has at least 4 parts
                try {
                    val timestamp = inputDateFormat.parse(parts[0])
                    val formattedTimestamp = dateOnlyFormat.format(timestamp)
                    timestamp != null && formattedTimestamp == selectedDateString
                } catch (e: Exception) {
                    false // Skip malformed lines
                }
            } else {
                false // Skip lines that do not have at least 4 parts
            }
        }.joinToString("\n") // Rejoin filtered lines
    }





















    @Composable
    fun DisconnectedScreen() {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                            MaterialTheme.colorScheme.secondary.copy(alpha = 0.8f)
                        )
                    )
                )
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Spacer(modifier = Modifier.weight(1f))

                // Always display battery percentage at the top
                Text(
                    text = "Battery: $batteryPercentage",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                // Conditionally display "Leads Disconnected"
                if (areLeadsDisconnected) {
                    Text(
                        text = "Leads Disconnected",
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Ensure the leads are properly connected to your body. If issues persist, touch a grounded metal object to discharge static electricity.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                // Request Data Button
                Button(
                    onClick = { requestFileFromDevice() },
                    modifier = Modifier.padding(vertical = 16.dp)
                ) {
                    Text("Request Data")
                }
            }
        }
    }






    @Composable
    fun DeviceSelectionScreen() {
        val context = LocalContext.current
        val scope = rememberCoroutineScope()

        LaunchedEffect(Unit) {
            scope.launch {
                delay(5000) // Show progress indicator for 5 seconds
                showProgressIndicator = false
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (showProgressIndicator) {
                CircularProgressIndicator()
                Spacer(modifier = Modifier.height(16.dp))
                Text("Scanning for devices...")
            } else {
                if (foundDevices.isEmpty()) {
                    Text("No devices found.")
                } else {
                    Text("Devices found:", style = MaterialTheme.typography.headlineMedium)
                    Spacer(modifier = Modifier.height(16.dp))
                    Column(
                        modifier = Modifier.verticalScroll(rememberScrollState())
                    ) {
                        foundDevices.forEach { device ->
                            Button(
                                onClick = { connectToDevice(device) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(text = device.name ?: "Unnamed Device", style = MaterialTheme.typography.bodyLarge)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    @Composable
    fun LiveDataScreen() {
        // State to track the connection status
        val isConnected = remember { mutableStateOf(true) }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp) // Add padding around the screen
        ) {
            Button(
                onClick = { requestFileFromDevice() },
                modifier = Modifier
                    .align(Alignment.BottomCenter) // Align button to the bottom center
            ) {
                Text(text = "Request Data")
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                            MaterialTheme.colorScheme.secondary.copy(alpha = 0.8f)
                        )
                    )
                )
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            if (!isConnected.value) {
                // Show "Disconnected" screen
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Text(
                        text = "Disconnected",
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Please reconnect your device.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                // Show values screen
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Add Battery Percentage Display
                    Text(
                        text = "Battery: $batteryPercentage", // Use the batteryPercentage state
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color.White,
                        modifier = Modifier
                            .align(Alignment.End) // Align to the top-right of the screen
                            .padding(8.dp)
                    )

                    Text(
                        text = "Heart Monitor",
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Column(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // BPM Card
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(16.dp)
                                    .fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "BPM",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Text(
                                    text = bpm,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.primary,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(top = 8.dp)
                                )
                            }
                        }
                        // RR Interval Card
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(16.dp)
                                    .fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "RR Interval",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Text(
                                    text = "${rrInterval} ms",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.primary,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(top = 8.dp)
                                )
                            }
                        }
                        // RMSSD Card with Conditional "ms"
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(16.dp)
                                    .fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "RMSSD",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Text(
                                    text = if (rmssd.trim().equals("Calculating", ignoreCase = true)) {
                                        "Calculating" // Only display "Calculating"
                                    } else {
                                        "$rmssd ms" // Append "ms" for numeric values
                                    },
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.primary,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(top = 8.dp)
                                )
                                // Always show progress, even during "calculating"
                                Text(
                                    text = RMSSDProgress,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Stress Card with Progress
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(16.dp)
                                    .fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = Stress,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.primary,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = StressProgress,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                        // Heart Rate Status Card
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                        ) {
                            Text(
                                text = heartRateStatus,
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .padding(16.dp)
                                    .fillMaxWidth(),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }

    private fun processLiveData(data: String) {
        val values = data.split(",")
        if (values.size >= 8) { // Ensure the data has enough fields for battery status
            rrInterval = values[0]
            bpm = values[1]
            rmssd = values[2]
            Stress = values[3]
            StressProgress = values[4]
            RMSSDProgress = values[5]
            heartRateStatus = when (values[6].toIntOrNull()) {
                0 -> "Good Heart Rate"
                1 -> "Tachycardia Detected"
                2 -> "Bradycardia Detected"
                else -> "Unknown"
            }
            batteryPercentage = values[7] // Update the battery percentage
            // Only update this if the data indicates normal operation
            areLeadsDisconnected = false
        }
    }


    private fun requestFileFromDevice() {
        if (bluetoothSocket == null) {
            Toast.makeText(this, "Device not connected", Toast.LENGTH_SHORT).show()
            return
        }
        // Show a toast message indicating that data has been requested
        Toast.makeText(this, "Data request sent to device...", Toast.LENGTH_SHORT).show()
        val command = "SEND_FILE\n" // Command to request the file
        sendBluetoothCommand(bluetoothSocket, command)
    }


    // Updated function to receive file data and invoke a callback
    private fun startReceivingFileData(inputStream: InputStream?, fileData: StringBuilder, onComplete: (String) -> Unit) {
        inputStream ?: return
        val buffer = ByteArray(1024)
        val handler = Handler(Looper.getMainLooper())

        Thread {
            try {
                var bytesRead: Int
                while (inputStream.read(buffer).also { bytesRead = it } > 0) {
                    val chunk = String(buffer, 0, bytesRead)
                    fileData.append(chunk)

                    if (chunk.contains("END_OF_FILE")) { // Check for end-of-file marker
                        handler.post {
                            onComplete(fileData.toString())
                        }
                        break
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                handler.post {
                    Toast.makeText(this, "Error receiving file data", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }




    @Composable
    fun DataCard(label: String, value: String) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
        ) {
            Row(
                modifier = Modifier
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.End
                )
            }
        }
    }

    private fun restartScan() {
        bluetoothAdapter.cancelDiscovery() // Stop ongoing discovery
        foundDevices.clear()
        showProgressIndicator = true
        startBluetoothScan()
    }

    private fun startBluetoothScan() {
        if (!hasRequiredBluetoothPermissions()) {
            requestRelevantRuntimePermissions()
        } else {
            try {
                bluetoothAdapter.cancelDiscovery() // Ensure any existing scan is stopped

                if (bluetoothAdapter.isEnabled) {
                    val filter = IntentFilter(BluetoothDevice.ACTION_FOUND)
                    unregisterReceiverSafely() // Unregister any existing receiver
                    registerReceiver(receiver, filter)

                    bluetoothAdapter.startDiscovery()
                    Toast.makeText(this, "Scanning for Bluetooth devices...", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Bluetooth is disabled", Toast.LENGTH_SHORT).show()
                }
            } catch (e: SecurityException) {
                Toast.makeText(this, "Permission denied for scanning", Toast.LENGTH_SHORT).show()
                requestRelevantRuntimePermissions()
            }
        }
    }

    private fun unregisterReceiverSafely() {
        try {
            unregisterReceiver(receiver)
        } catch (e: IllegalArgumentException) {
            // Receiver was not registered; safe to ignore
        }
    }

    private fun connectToDevice(device: BluetoothDevice) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED) {
            bluetoothAdapter.cancelDiscovery()
        } else {
            Toast.makeText(this, "Permission required to stop discovery", Toast.LENGTH_SHORT).show()
            requestRelevantRuntimePermissions()
            return
        }

        try {
            val uuid = device.uuids?.get(0)?.uuid ?: return
            bluetoothSocket = device.createRfcommSocketToServiceRecord(uuid)
            bluetoothSocket?.connect()

            Toast.makeText(this, "Connected to ${device.name}", Toast.LENGTH_SHORT).show()
            isConnected = true

            // Automatically sync time after connection
            syncTimeWithDevice(bluetoothSocket)

            startListeningForData(bluetoothSocket?.inputStream)
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to connect to ${device.name}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startListeningForData(inputStream: InputStream?) {
        inputStream ?: return
        val buffer = ByteArray(1024)
        val handler = Handler(Looper.getMainLooper())
        val fileBuffer = StringBuilder()
        var isReceivingFile = false

        Thread {
            try {
                while (true) {
                    val bytesRead = inputStream.read(buffer)
                    if (bytesRead > 0) {
                        val data = String(buffer, 0, bytesRead).trim() // Trim unnecessary whitespace
                        handler.post {
                            if (data.isNotEmpty()) {
                                when {
                                    data.startsWith("Disconnected") -> {
                                        val values = data.split(",")
                                        if (values.size >= 2) { // Ensure at least 2 fields for "Disconnected"
                                            batteryPercentage = values[1] // Update battery percentage
                                            areLeadsDisconnected = true // Indicate leads are disconnected

                                            // Process additional fields if present
                                            if (values.size >= 3) {
                                                liveData = values[2] // Example: Update live data to include additional info
                                            }
                                        } else {
                                            areLeadsDisconnected = true // Fallback if fields are insufficient
                                            liveData = "Disconnected" // Set default disconnected state
                                        }
                                    }

                                    data.startsWith("FILE_START") -> {
                                        fileBuffer.clear()
                                        isReceivingFile = true
                                    }
                                    data.startsWith("FILE_END") -> {
                                        isReceivingFile = false
                                        fileData = fileBuffer.toString()
                                        currentScreen = "DataDisplay" // Navigate to file display
                                    }
                                    isReceivingFile -> {
                                        fileBuffer.append(data).append("\n")
                                    }
                                    else -> {
                                        // Process live data
                                        val values = data.split(",")
                                        if (values.size == 8) { // Ensure sufficient fields
                                            rrInterval = values[0]
                                            bpm = values[1]
                                            rmssd = values[2]
                                            Stress = values[3]
                                            StressProgress = values[4]
                                            RMSSDProgress = values[5]
                                            heartRateStatus = when (values[6].toIntOrNull()) {
                                                0 -> "Good Heart Rate"
                                                1 -> "Tachycardia Detected"
                                                2 -> "Bradycardia Detected"
                                                else -> "Unknown"
                                            }
                                            batteryPercentage = values[7]
                                            isConnected = true
                                            areLeadsDisconnected = false // Reset leads disconnection
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                handler.post {
                    liveData = "Disconnected"
                    isConnected = false
                    areLeadsDisconnected = false // Reset leads disconnection
                }
            }
        }.start()
    }






    private fun syncTimeWithDevice(socket: BluetoothSocket?) {
        // Get the current time and date
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)
        val second = calendar.get(Calendar.SECOND)
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val month = calendar.get(Calendar.MONTH) + 1 // Convert 0-based month to 1-based
        val year = calendar.get(Calendar.YEAR)

        // Format the command
        val command = "SET_TIME,$hour,$minute,$second,$day,$month,$year\n"

        // Send the command via Bluetooth
        try {
            socket?.outputStream?.write(command.toByteArray())
            Toast.makeText(this, "Time synced: $hour:$minute:$second $day/$month/$year\n", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Failed to sync time", Toast.LENGTH_SHORT).show()
        }
    }



    private fun sendBluetoothCommand(socket: BluetoothSocket?, command: String) {
        try {
            socket?.outputStream?.write(command.toByteArray())
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun requestRelevantRuntimePermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN
            )
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        if (!hasRequiredBluetoothPermissions()) {
            requestPermissionsLauncher.launch(permissions)
        } else {
            startBluetoothScan()
        }
    }

    private fun hasRequiredBluetoothPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            hasPermission(Manifest.permission.BLUETOOTH_CONNECT) &&
                    hasPermission(Manifest.permission.BLUETOOTH_SCAN)
        } else {
            hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    private fun hasPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(receiver)
            unregisterReceiver(connectionStateReceiver) // Unregister the connection state receiver
            bluetoothSocket?.close()
        } catch (e: Exception) {
            // Handle exception
        }
    }

    fun prepareChartData(rawData: String): LineData {
        val entries = mutableListOf<Entry>()
        val lines = rawData.lines()

        println("Filtered Data for Chart: $rawData") // Debugging filtered data

        lines.forEachIndexed { index, line ->
            val parts = line.split(",")
            if (parts.size >= 4) {
                try {
                    val stressLevel = parts[3].toFloatOrNull()
                    if (stressLevel != null) {
                        entries.add(Entry(index.toFloat(), stressLevel))
                    }
                } catch (e: Exception) {
                    println("Error parsing line: $line")
                }
            }
        }

        if (entries.isEmpty()) {
            println("No entries created for the chart. Check your filtered data.")
        }

        val dataSet = LineDataSet(entries, "Stress Levels").apply {
            color = android.graphics.Color.BLUE
            valueTextColor = android.graphics.Color.BLACK
            lineWidth = 2f
            setCircleColor(android.graphics.Color.RED)
            setDrawValues(false)
        }

        return LineData(dataSet)
    }










    @Preview(showBackground = true)
    @Composable
    fun PreviewMyScreen() {
        UbiEKGTheme {
            MainScreen()
        }
    }
}